#include <iostream>
#include <fstream>
#define N 1877
using namespace std;

int main()
{
    fstream file;
    int allCharactersAmount=0;
    string words[N];

    file.open("tekst.txt", ios::in | ios::out);
    for(int i=0; i<N; i++)
        file >> words[i];

    int letters[255];

    for(int i=65; i<=90; i++)
        letters[i]=0;

    for(int i=0; i<N; i++)
    {
        int charactersAmount = words[i].size();

        for(int j=0; j<charactersAmount; j++)
            letters[words[i][j]]++;

        allCharactersAmount+=charactersAmount;
    }

    cout.precision(2);

    cout << "Ilosc wszystkich slow: " << allCharactersAmount << endl;
    for(int i=65; i<=90; i++)
    {
        double proc = ((double)letters[i]/(double)allCharactersAmount)*100;
        cout << fixed << char(i) << ": " << letters[i] << " " << "(" << proc << "%)" << endl;
    }
    return 0;
}
