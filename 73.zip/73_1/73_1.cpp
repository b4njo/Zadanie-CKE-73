#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    fstream file;
    int numberOfWords=0;
    string words[1877];

    file.open("tekst.txt", ios::in | ios::out);
    for(int i=0; i<1877; i++)
        file >> words[i];

    for(int i=0; i<1877; i++)
    {
        int charactersNumber = words[i].size();
        for(int j=0; j<charactersNumber-1; j++)
            if(words[i][j]==words[i][j+1])
            {
                numberOfWords++;
                break;
            }
    }

    cout << numberOfWords;
    return 0;
}
